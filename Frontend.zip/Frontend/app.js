// ─── Vibify — vanilla JS app (no framework) ─────────────────────────────────
// Final frontend connected to FastAPI backend.
//
// Backend endpoints expected:
//   POST /generate
//   POST /interrupt
//
// Generate request:
//   multipart/form-data
//     product_name
//     frame_size
//     duration
//     shots
//     product_image
//     audio
//     audio_file
//
// Generate response:
// {
//   success: true,
//   video_url: "/generated/xxxx.mp4",
//   filename: "xxxx.mp4",
//   shots: [],
//   shot_chain: [],
//   audio_applied: true/false,
//   audio_warning: null/string
// }

const LIBRARY_KEY = 'vibify_library'

function loadLibrary() {
  try {
    const saved = localStorage.getItem(LIBRARY_KEY)

    if (!saved) {
      return []
    }

    const videos = JSON.parse(saved)

    return Array.isArray(videos)
      ? videos
      : []
  } catch (error) {
    console.error('Could not load library:', error)
    return []
  }
}

function saveLibrary(videos) {
  try {
    localStorage.setItem(
      LIBRARY_KEY,
      JSON.stringify(videos)
    )
  } catch (error) {
    console.error('Could not save library:', error)
  }
}

// ============================================================================
// BACKEND LIBRARY
// ============================================================================

function normalizeLibraryVideo(video) {
  if (!video) {
    return null
  }

  return {
    ...video,

    // Backend uses snake_case.
    // Frontend uses camelCase.
    videoUrl:
      video.videoUrl ||
      video.video_url ||
      '',

    productName:
      video.productName ||
      video.product_name ||
      'Generated video',
    
    prompt:
      video.prompt ||
      video.product_prompt ||
      video.product_name ||
      video.productName ||
      '',

    frameSize:
      video.frameSize ||
      video.frame_size ||
      'Landscape 16:9',

    duration:
      video.duration || 0,

    audio:
      video.audio || '',

    filename:
      video.filename || '',

    // Backend currently does not save thumbnails,
    // so this can be empty and the library will
    // use the actual video instead.
    thumbnail:
      video.thumbnail || '',

    clips:
      Array.isArray(video.clips)
        ? video.clips
        : Array.isArray(video.shots)
          ? video.shots
          : [],

    savedAt:
      video.savedAt ||
      video.saved_at ||
      ''
  }
}


async function loadLibraryFromBackend() {
  try {
    const response = await fetch('/api/library')

    if (!response.ok) {
      throw new Error(
        `Library request failed with HTTP ${response.status}`
      )
    }

    const result = await response.json()

    if (!result.success) {
      throw new Error(
        result.detail ||
        'Could not load library.'
      )
    }

    state.videos = Array.isArray(result.videos)
      ? result.videos
          .map(normalizeLibraryVideo)
          .filter(Boolean)
      : []

    render()

  } catch (error) {
    console.error(
      'Could not load library from backend:',
      error
    )

    // Keep any old localStorage videos as a fallback.
    state.videos = loadLibrary()

    render()
  }
}

const AUDIO_OPTIONS = [
  'Cinematic 🎬',
  'Upbeat 🎵',
  'Energetic ⚡',
  'Premium ✨',
  'Modern 🔷',
  'Corporate 💼',
  'Ambient 🌿',
  'Playful 😊',
  'Inspirational 🌟',
  'Futuristic 🚀',
]

const CAMERA_MOTION_OPTIONS = [
  'Slow pan left',
  'Slow pan right',
  'Zoom in',
  'Zoom out',
  'Orbit',
  'Static',
]

const PRODUCT_MOVEMENT_OPTIONS = [
  'Static',
  'Slow rotate',
  'Floating drift',
  'Gentle bounce',
  'Pulse zoom',
]

const LIGHTING_OPTIONS = [
  'Studio soft',
  'Golden hour',
  'Neon rim',
  'Natural diffuse',
  'High contrast',
  'Candlelight',
]

const ONBOARDING_STEPS = [
  {
    step: 1,
    total: 3,
    targetId: 'ob-dropzone',
    text: 'Start by dropping in a product photo here.',
  },
  {
    step: 2,
    total: 3,
    targetId: 'ob-camera-motion',
    text: 'Choose a camera motion, then describe the effect, background, and background motion you want.',
  },
  {
    step: 3,
    total: 3,
    targetId: 'ob-generate',
    text: 'Then hit generate and we\'ll do the rest.',
  },
]

function defaultClip() {
  return {
    cameraMotion: CAMERA_MOTION_OPTIONS[0],
    productMovement: PRODUCT_MOVEMENT_OPTIONS[0],
    lighting: LIGHTING_OPTIONS[0],

    effect: '',
    background: '',
    backgroundMotion: '',
    textOnVideo: '',
    creativeDirection: '',
  }
}

function clipsForDuration(duration) {
  if (duration === '10 seconds') return 2
  if (duration === '15 seconds') return 3
  return 1
}

const state = {
  // Screens
  screen: 'landing', // landing | auth | create | library | settings

  // Authentication
  authMode: 'login',
  isGuest: false,
  userName: '',
  userEmail: '',

  // Library
  videos: [],
  selectedLibraryVideo: null,
  guestBannerDismissed: false,


  // Onboarding
  onboardingDone: false,
  obStep: 0,

  // ────────────────────────────────────────────────────────────
  // Create Video
  // ────────────────────────────────────────────────────────────

  imageDataUrl: null,
  imageFile: null,
  imageSizeError: '',

  productName: '',
  productNameTouched: false,
  submitAttempted: false,

  duration: '5 seconds',
  frameSize: 'Landscape 16:9',

  audio: AUDIO_OPTIONS[0],
  audioFileName: '',
  audioFile: null,

  currentClip: 0,
  clips: [defaultClip()],

  status: 'idle', // idle | processing | done | failed
  progress: 0,

  generatedVideo: null,
  savedToLibrary: false,

  generationError: '',
  generationWarning: '',

  openDropdown: null,
}

let progressTimer = null
let generationController = null

// ============================================================================
// RENDER
// ============================================================================

function render() {
  const app = document.getElementById('app')

  if (!app) {
    console.error('Vibify: #app element was not found.')
    return
  }

  // Remember create screen scroll position before rebuilding DOM.
  const oldMain = app.querySelector('.create-main')
  const savedScrollTop = oldMain ? oldMain.scrollTop : 0

  if (state.screen === 'landing') {
    app.innerHTML = renderLanding()
  } else if (state.screen === 'auth') {
    app.innerHTML = renderAuth()
  } else if (state.screen === 'create') {
    app.innerHTML = renderCreate()
  } else if (state.screen === 'library') {
    app.innerHTML = renderLibrary()
  } else if (state.screen === 'settings') {
    app.innerHTML = renderSettings()
  }

  attachHandlers()

  const newMain = app.querySelector('.create-main')

  if (newMain) {
    newMain.scrollTop = savedScrollTop
  }

  requestAnimationFrame(() => {
    positionOnboardingTooltip()
  })
}

// ============================================================================
// LANDING
// ============================================================================

function renderLanding() {
  return `
    <div class="landing">

      <div class="landing-blob-1"></div>
      <div class="landing-blob-2"></div>

      <div class="landing-content">

        <div class="landing-logo"></div>

        <p class="landing-title">
          Vibify
        </p>

        <p class="landing-tagline">
          Turn any photo into a scroll-stopping video in seconds.
        </p>

        <p class="landing-sub">
          No editing skills needed.
        </p>

        <button
          class="btn btn-primary btn-pill"
          id="start-creating"
          style="padding:13px 32px;"
        >
          Start creating →
        </button>

      </div>

    </div>
  `
}

// ============================================================================
// AUTH
// ============================================================================

function renderAuth() {
  const isSignup = state.authMode === 'signup'

  return `
    <div class="auth-wrap">

      <div class="auth-card">

        <div class="auth-header">

          <div class="logo-mark"></div>

          <p style="font-size:20px;font-weight:500;margin:0;">
            Welcome to Vibify
          </p>

          <p style="
            color:var(--text-muted);
            font-size:12px;
            margin:6px 0 0;
          ">
            Turn images into videos in seconds
          </p>

        </div>

        <div class="auth-tabs">

          <div
            class="auth-tab ${!isSignup ? 'active' : ''}"
            data-auth-mode="login"
          >
            Log in
          </div>

          <div
            class="auth-tab ${isSignup ? 'active' : ''}"
            data-auth-mode="signup"
          >
            Sign up
          </div>

        </div>

        <div style="
          display:flex;
          flex-direction:column;
          gap:12px;
          margin-bottom:16px;
        ">

          <div>
            <label class="field-label">
              Email
            </label>

            <input
              class="text-input"
              id="auth-email"
              type="email"
              placeholder="name@company.com"
            />
          </div>

          <div>
            <label class="field-label">
              Password
            </label>

            <input
              class="text-input"
              id="auth-password"
              type="password"
              placeholder="••••••••"
            />
          </div>

          ${
            isSignup
              ? `
                <div>
                  <label class="field-label">
                    Confirm password
                  </label>

                  <input
                    class="text-input"
                    id="auth-confirm"
                    type="password"
                    placeholder="••••••••"
                  />
                </div>
              `
              : ''
          }

        </div>

        <p
          id="auth-error"
          class="error-msg hidden"
          role="alert"
          aria-live="polite"
        ></p>

        <button
          class="btn btn-primary"
          id="auth-submit"
          style="
            width:100%;
            margin-bottom:16px;
          "
        >
          ${isSignup ? 'Sign up' : 'Log in'}
        </button>

        <div class="auth-divider">

          <div class="line"></div>

          <span>
            or
          </span>

          <div class="line"></div>

        </div>

        <button
          class="btn btn-outline"
          id="auth-google"
          style="
            width:100%;
            margin-bottom:10px;
          "
        >
          Continue with Google
        </button>

        <div
          class="guest-link"
          id="auth-guest"
        >
          Continue as guest
        </div>

      </div>

    </div>
  `
}

// ============================================================================
// DROPDOWN FIELD
// ============================================================================

function dropdownField(id, value, label) {
  return `
    <div
      class="dropdown"
      data-dropdown-id="${escapeAttr(id)}"
    >

      ${
        label
          ? `
            <label class="field-label">
              ${escapeHtml(label)}
            </label>
          `
          : ''
      }

      <div
        class="dropdown-field"
        data-dropdown-toggle="${escapeAttr(id)}"
      >

        <span>
          ${escapeHtml(value)}
        </span>

        <span>
          ▾
        </span>

      </div>

    </div>
  `
}

// ============================================================================
// CREATE VIDEO
// ============================================================================

function renderCreate() {
  const total = clipsForDuration(state.duration)

  const clip =
    state.clips[state.currentClip] ||
    defaultClip()
  
  const video = state.generatedVideo

  const locked =
    state.currentClip > 0

  const nameError =
    getNameError()

  const showNameError =
    (state.productNameTouched || state.submitAttempted) &&
    nameError

  return `
    <div class="app-shell">

      ${renderSidebar('create')}

      <div
        style="
          flex:1;
          display:flex;
          flex-direction:column;
          height:100vh;
          overflow:hidden;
          position:relative;
        "
      >

        ${
          !state.onboardingDone
            ? `<div class="ob-overlay"></div>`
            : ''
        }

        ${
          !state.onboardingDone
            ? renderOnboardingTooltip()
            : ''
        }

        <div class="top-bar">

          ${
            state.isGuest
              ? `
                <span class="guest-tag">
                  Guest
                </span>
              `
              : `
                <div style="
                  display:flex;
                  align-items:center;
                  gap:10px;
                ">

                  <div class="avatar">
                    ${escapeHtml(
                      (state.userName || 'U')
                        .slice(0, 2)
                        .toUpperCase()
                    )}
                  </div>

                  <span style="
                    color:var(--text-secondary);
                    font-size:14px;
                  ">
                    ${escapeHtml(state.userName)}
                  </span>

                </div>
              `
          }

        </div>

        <div class="create-main">

          <!-- ========================================================= -->
          <!-- LEFT -->
          <!-- ========================================================= -->

          <div class="create-left">

            <div>

              <h1 style="
                font-size:30px;
                margin-bottom:6px;
              ">
                Create video
              </h1>

              <p style="
                margin:0;
                font-size:14px;
                color:var(--text-muted);
              ">
                ${
                  total === 1
                    ? 'Upload a product image to generate a short AI video'
                    : `This video needs ${total} clips (5s each) — configure one at a time`
                }
              </p>

            </div>

            <!-- ======================================================= -->
            <!-- FIXED VIDEO SETTINGS -->
            <!-- ======================================================= -->

            <div
              class="fixed-box ${locked ? 'locked' : ''}"
              id="ob-dropzone"
            >

              ${
                locked
                  ? `
                    <div class="lock-badge">
                      🔒 LOCKED — SET ON CLIP 1
                    </div>
                  `
                  : ''
              }

              <!-- PRODUCT IMAGE -->

              <div>

                <label class="field-label">
                  Product image
                </label>

                <div
                  class="
                    dropzone
                    ${state.imageDataUrl ? 'filled' : 'empty'}
                    ${state.imageSizeError ? 'error' : ''}
                  "
                  id="dropzone"
                >

                  ${
                    state.imageDataUrl
                      ? `
                        <img
                          src="${state.imageDataUrl}"
                          alt="Product preview"
                        />

                        <div class="dropzone-overlay">

                          <p style="
                            margin:0;
                            font-size:13px;
                            font-weight:500;
                          ">
                            Click to change image
                          </p>

                        </div>
                      `
                      : `
                        <div style="
                          color:var(--text-muted);
                          margin-bottom:10px;
                        ">
                          ⬆
                        </div>

                        <p style="
                          margin:0 0 6px;
                          font-size:14px;
                          color:var(--text-secondary);
                          font-weight:500;
                        ">
                          Drop image here, or click to browse
                        </p>

                        <p style="
                          margin:0;
                          font-size:12px;
                          color:var(--text-muted);
                        ">
                          JPG, PNG, WEBP — up to 20 MB
                        </p>
                      `
                  }

                </div>

                <input
                  type="file"
                  id="file-input"
                  accept="image/jpeg,image/png,image/webp"
                  class="hidden"
                />

                ${
                  state.imageSizeError
                    ? `
                      <p
                        class="error-msg"
                        role="alert"
                        aria-live="polite"
                      >
                        ${escapeHtml(state.imageSizeError)}
                      </p>
                    `
                    : ''
                }

                ${
                  state.submitAttempted &&
                  !state.imageFile &&
                  !state.imageSizeError
                    ? `
                      <p
                        class="error-msg"
                        role="alert"
                        aria-live="polite"
                      >
                        Please upload a product image.
                      </p>
                    `
                    : ''
                }

              </div>

              <!-- PRODUCT NAME -->

              <div>

                <label class="field-label">
                  Product name
                </label>

                <input
                  class="
                    text-input
                    ${showNameError ? 'error' : ''}
                  "
                  id="product-name"
                  type="text"
                  value="${escapeAttr(state.productName)}"
                  placeholder="e.g. Flower Bouquet"
                  aria-required="true"
                  aria-invalid="${!!showNameError}"
                />

                ${
                  showNameError
                    ? `
                      <p
                        class="error-msg"
                        role="alert"
                        aria-live="polite"
                      >
                        ${escapeHtml(nameError)}
                      </p>
                    `
                    : ''
                }

              </div>

              <!-- DURATION -->

              <div>

                <label class="field-label">
                  Video duration
                </label>

                <div class="pill-group">

                  ${[
                    '5 seconds',
                    '10 seconds',
                    '15 seconds',
                  ]
                    .map(
                      option => `
                        <button
                          class="
                            pill-btn
                            ${
                              state.duration === option
                                ? 'active'
                                : ''
                            }
                          "
                          data-duration="${option}"
                          ${
                            locked ||
                            state.status === 'processing'
                              ? 'disabled'
                              : ''
                          }
                        >
                          ${option}
                        </button>
                      `
                    )
                    .join('')}

                </div>

              </div>

              <!-- FRAME SIZE -->

              <div>

                <label class="field-label">
                  Frame size
                </label>

                <div class="pill-group">

                  ${[
                    {
                      label: 'Square',
                      sub: '1:1',
                      value: 'Square 1:1',
                    },
                    {
                      label: 'Landscape',
                      sub: '16:9',
                      value: 'Landscape 16:9',
                    },
                    {
                      label: 'Portrait',
                      sub: '9:16',
                      value: 'Portrait 9:16',
                    },
                  ]
                    .map(
                      ({
                        label,
                        sub,
                        value,
                      }) => `
                        <button
                          class="
                            pill-btn
                            frame-pill
                            ${
                              state.frameSize === value
                                ? 'active'
                                : ''
                            }
                          "
                          data-frame="${value}"
                          ${
                            locked ||
                            state.status === 'processing'
                              ? 'disabled'
                              : ''
                          }
                        >

                          <div
                            class="frame-pill-swatch"
                            style="
                              width:${
                                value.startsWith('Square')
                                  ? 20
                                  : value.startsWith(
                                      'Landscape'
                                    )
                                  ? 28
                                  : 14
                              }px;
                              height:${
                                value.startsWith('Square')
                                  ? 20
                                  : value.startsWith(
                                      'Landscape'
                                    )
                                  ? 16
                                  : 24
                              }px;
                            "
                          ></div>

                          <span>
                            ${label}
                          </span>

                          <span style="
                            font-size:10px;
                            opacity:0.7;
                          ">
                            ${sub}
                          </span>

                        </button>
                      `
                    )
                    .join('')}

                </div>

              </div>

              <!-- AUDIO -->

              <div>

                <label class="field-label">
                  Audio
                </label>

                ${dropdownField(
                  'audio',
                  state.audio,
                  ''
                )}

                <div class="or-divider">
                  or
                </div>

                <div
                  class="audio-upload"
                  id="audio-upload"
                >
                  <span>
                    ${
                      state.audioFileName
                        ? `🎵 ${escapeHtml(
                            state.audioFileName
                          )}`
                        : '⬆ Upload your own audio'
                    }
                  </span>
                </div>

                <input
                  type="file"
                  id="audio-input"
                  accept="audio/*"
                  class="hidden"
                />

                ${
                  state.audioFileName
                    ? `
                      <button
                        type="button"
                        class="btn btn-outline"
                        id="remove-audio-file"
                        style="
                          margin-top:8px;
                          padding:6px 10px;
                          font-size:11px;
                        "
                      >
                        Remove uploaded audio
                      </button>
                    `
                    : ''
                }

              </div>

            </div>

            <!-- ======================================================= -->
            <!-- CLIP SETTINGS -->
            <!-- ======================================================= -->

            <div class="settings-box">

              <p class="settings-box-title">
                ${
                  total === 1
                    ? 'SETTINGS'
                    : `CLIP ${state.currentClip + 1} OF ${total} SETTINGS`
                }
              </p>

              <div id="ob-camera-motion">

                ${dropdownField(
                  'cameraMotion',
                  clip.cameraMotion,
                  'Camera motion'
                )}

              </div>

              ${dropdownField(
                'productMovement',
                clip.productMovement,
                'Product movement'
              )}

              ${dropdownField(
                'lighting',
                clip.lighting,
                'Lighting'
              )}

              <!-- EFFECT -->

              <div>

                <label class="field-label">
                  Effect
                  <span class="optional">
                    (optional)
                  </span>
                </label>

                <input
                  class="text-input"
                  id="clip-effect"
                  type="text"
                  value="${escapeAttr(clip.effect)}"
                  placeholder="e.g. Snow, Confetti, Light rays…"
                />

              </div>

              <!-- BACKGROUND -->

              <div>

                <label class="field-label">
                  Background
                  <span class="optional">
                    (optional)
                  </span>
                </label>

                <input
                  class="text-input"
                  id="clip-background"
                  type="text"
                  value="${escapeAttr(
                    clip.background
                  )}"
                  placeholder="e.g. At a cafe shop, Mountain sunset…"
                />

              </div>

              <!-- BACKGROUND MOTION -->

              <div>

                <label class="field-label">
                  Background motion
                  <span class="optional">
                    (optional)
                  </span>
                </label>

                <input
                  class="text-input"
                  id="clip-background-motion"
                  type="text"
                  value="${escapeAttr(
                    clip.backgroundMotion
                  )}"
                  placeholder="e.g. Subtle drift, Ambient particles…"
                />

              </div>

              <!-- TEXT ON VIDEO -->

              <div>

                <label class="field-label">
                  Text on video
                  <span class="optional">
                    (optional)
                  </span>
                </label>

                <input
                  class="text-input"
                  id="clip-text"
                  type="text"
                  value="${escapeAttr(
                    clip.textOnVideo
                  )}"
                  placeholder="e.g. 20% OFF TODAY"
                />

              </div>

              <!-- ADDITIONAL DIRECTION -->

              <div>

                <label class="field-label">
                  Additional creative direction
                  <span class="optional">
                    (optional)
                  </span>
                </label>

                <textarea
                  class="text-input"
                  id="clip-direction"
                  rows="3"
                  placeholder="e.g. Make it feel warm and cozy, like a rainy afternoon"
                >${escapeHtml(
                  clip.creativeDirection
                )}</textarea>

              </div>

            </div>

            <!-- ======================================================= -->
            <!-- CLIP NAV / GENERATE -->
            <!-- ======================================================= -->

            <div
              id="ob-generate"
              style="
                display:flex;
                gap:10px;
              "
            >

              ${
                state.currentClip > 0
                  ? `
                    <button
                      class="btn btn-outline"
                      id="clip-prev"
                      ${
                        state.status === 'processing'
                          ? 'disabled'
                          : ''
                      }
                    >
                      ← Previous
                    </button>
                  `
                  : ''
              }

              ${
                state.currentClip < total - 1
                  ? `
                    <button
                      class="btn btn-primary"
                      id="clip-next"
                      style="flex:1;"
                      ${
                        state.status === 'processing'
                          ? 'disabled'
                          : ''
                      }
                    >
                      Next →
                    </button>
                  `
                  : `
                    <button
                      class="btn btn-primary"
                      id="generate-btn"
                      style="flex:1;"
                      ${
                        state.status === 'processing'
                          ? 'disabled'
                          : ''
                      }
                    >
                      ${
                        state.status === 'processing'
                          ? 'Generating…'
                          : 'Generate video'
                      }
                    </button>
                  `
              }

            </div>

          </div>

          <!-- ========================================================= -->
          <!-- RIGHT -->
          <!-- ========================================================= -->

          <div class="create-right">

            <!-- STATUS CARD -->

            <div class="status-card">

              <p class="status-title">
                Status
              </p>

              <div class="status-row">

                <div
                  class="
                    status-dot
                    ${
                      state.status !== 'idle'
                        ? state.status
                        : ''
                    }
                  "
                ></div>

                <span style="
                  font-size:14px;
                  color:var(--text-secondary);
                ">
                  ${
                    state.status === 'idle'
                      ? 'Waiting…'
                      : state.status === 'processing'
                      ? 'Processing…'
                      : state.status === 'done'
                      ? 'Done'
                      : 'Failed — try again'
                  }
                </span>

              </div>

              ${
                state.status === 'processing'
                  ? `
                    <div class="progress-track">

                      <div
                        class="progress-fill"
                        style="
                          width:${state.progress}%;
                        "
                      ></div>

                    </div>

                    <span class="progress-pct">
                      ${Math.round(state.progress)}%
                    </span>
                  `
                  : ''
              }

              ${
                state.status === 'failed'
                  ? `
                    <button
                      class="btn btn-outline"
                      id="retry-btn"
                      style="
                        margin-top:10px;
                        padding:7px 12px;
                        font-weight:400;
                      "
                    >
                      Try again
                    </button>
                  `
                  : ''
              }

              ${
                state.generationError
                  ? `
                    <p
                      class="error-msg"
                      role="alert"
                      aria-live="polite"
                      style="
                        margin-top:10px;
                        white-space:pre-wrap;
                      "
                    >
                      ${escapeHtml(
                        state.generationError
                      )}
                    </p>
                  `
                  : ''
              }

              ${
                state.generationWarning
                  ? `
                    <p style="
                      margin:10px 0 0;
                      font-size:11px;
                      line-height:1.5;
                      color:var(--text-muted);
                    ">
                      ${escapeHtml(
                        state.generationWarning
                      )}
                    </p>
                  `
                  : ''
              }

            </div>

            <!-- VIDEO CARD -->

            <div class="video-card">

              <p class="video-title">
                Video
              </p>

              <div class="video-box">

                ${
                  state.status === 'processing'
                    ? `
                      <div class="spinner"></div>

                      <p style="
                        margin:0;
                        font-size:12px;
                        color:var(--text-secondary);
                      ">
                        Generating your video…
                        ${Math.round(state.progress)}%
                      </p>
                    `
                    : state.status === 'done' &&
                      state.generatedVideo
                    ? `
                      <div
                        class="video-inner"
                        style="
                          aspect-ratio:${videoAspectRatio()};
                        "
                      >

                        <video
                          id="library-video-player"
                          controls
                          playsinline
                          preload="metadata"
                          style="
                            width:100%;
                            height:100%;
                            display:block;
                            object-fit:contain;
                            background:#000;
                          "
                        >
                          <source
                            src="${escapeAttr(state.generatedVideo.videoUrl)}"
                            type="video/mp4"
                          />
                          Your browser does not support video playback.
                        </video>



                      </div>
                    `
                    : `
                      <div class="video-placeholder">

                        <div style="
                          font-size:22px;
                        ">
                          🎬
                        </div>

                        <p>
                          Your generated video will appear here
                        </p>

                      </div>
                    `
                }

              </div>

              ${
                state.status === 'processing'
                  ? `
                    <div class="cancel-row">

                      <button
                        class="btn btn-danger-outline"
                        id="cancel-btn"
                        style="
                          padding:9px 22px;
                        "
                      >
                        ✕ Cancel generation
                      </button>

                    </div>
                  `
                  : ''
              }

              ${
                state.status === 'done' &&
                state.generatedVideo
                  ? `
                    <div class="after-gen-actions">

                      <button
                        class="btn btn-primary"
                        id="save-btn"
                        ${
                          state.savedToLibrary
                            ? 'disabled'
                            : ''
                        }
                      >
                        ${
                          state.savedToLibrary
                            ? 'Saved ✓'
                            : 'Save'
                        }
                      </button>

                      <button
                        class="btn btn-outline"
                        id="download-btn"
                      >
                        Download
                      </button>

                      <button
                        class="btn btn-outline"
                        id="generate-again-btn"
                      >
                        Generate again
                      </button>

                    </div>

                    <p class="after-gen-note">
                      Save adds this video to your Library ·
                      Download saves it to your device
                    </p>
                  `
                  : ''
              }

            </div>

          </div>

        </div>

      </div>

    </div>
  `
}

// ============================================================================
// ONBOARDING
// ============================================================================

function renderOnboardingTooltip() {
  const step =
    ONBOARDING_STEPS[state.obStep] ||
    ONBOARDING_STEPS[0]

  return `
    <div
      class="ob-tooltip"
      id="ob-tooltip"
    >

      <p class="ob-tooltip-step">
        STEP ${step.step} OF ${step.total}
      </p>

      <p class="ob-tooltip-text">
        ${escapeHtml(step.text)}
      </p>

      <div class="ob-tooltip-actions">

        <span
          class="ob-skip"
          id="ob-skip"
        >
          Skip
        </span>

        <button
          class="ob-next"
          id="ob-next"
        >
          ${
            step.step === step.total
              ? 'Done'
              : 'Next →'
          }
        </button>

      </div>

    </div>
  `
}

function positionOnboardingTooltip() {
  if (state.onboardingDone) return

  const tooltip =
    document.getElementById('ob-tooltip')

  const step =
    ONBOARDING_STEPS[state.obStep]

  if (!step) return

  const target =
    document.getElementById(step.targetId)

  if (!tooltip || !target) return

  const rect =
    target.getBoundingClientRect()

  const tooltipWidth =
    tooltip.offsetWidth

  const tooltipHeight =
    tooltip.offsetHeight

  const gap = 16

  let top =
    rect.bottom + gap

  let left =
    rect.left

  if (
    left + tooltipWidth >
    window.innerWidth - 12
  ) {
    left =
      window.innerWidth -
      tooltipWidth -
      12
  }

  if (left < 12) {
    left = 12
  }

  if (
    top + tooltipHeight >
    window.innerHeight - 12
  ) {
    top =
      rect.top -
      tooltipHeight -
      gap
  }

  if (top < 12) {
    top = 12
  }

  tooltip.style.top =
    `${top}px`

  tooltip.style.left =
    `${left}px`
}

window.addEventListener(
  'scroll',
  positionOnboardingTooltip,
  true
)

window.addEventListener(
  'resize',
  positionOnboardingTooltip
)

// ============================================================================
// SIDEBAR
// ============================================================================

function renderSidebar(active) {
  const item = (
    id,
    icon,
    label
  ) => `
    <div
      class="
        nav-item
        ${active === id ? 'active' : ''}
      "
      data-nav="${id}"
    >
      <span class="nav-icon">
        ${icon}
      </span>

      <span>
        ${label}
      </span>
    </div>
  `

  return `
    <div class="sidebar">

      <div class="logo">

        <div class="logo-mark"></div>

        <span class="logo-text">
          Vibify
        </span>

      </div>

      ${item(
        'create',
        '⬆',
        'Upload'
      )}

      ${item(
        'library',
        '▤',
        'Library'
      )}

      ${item(
        'settings',
        '⚙',
        'Settings'
      )}

    </div>
  `
}

// ============================================================================
// LIBRARY
// ============================================================================

function renderLibrary() {
  // If a video is selected, show the video detail page.
  if (state.selectedLibraryVideo) {
    const video = state.selectedLibraryVideo

    return `
      <div class="app-shell">

        ${renderSidebar('library')}

        <div style="
          flex:1;
          padding:36px;
          overflow:auto;
        ">

          <button
            class="btn btn-outline"
            id="library-back"
            style="
              margin-bottom:24px;
              padding:8px 14px;
            "
          >
            ← Back to Library
          </button>

          <h1 style="
            font-size:26px;
            margin-bottom:6px;
          ">
            ${escapeHtml(
              video.productName ||
              'Generated video'
            )}
          </h1>

          <p style="
            color:var(--text-muted);
            font-size:13px;
            margin:0 0 24px;
          ">
            Saved video
          </p>

          <!-- VIDEO + DETAILS -->

          <div class="library-detail-layout">

            <!-- LEFT: VIDEO -->
            <div class="video-card">

              <p class="video-title">
                Video
              </p>

              <div class="video-box">

                <div
                  class="video-inner"
                  style="
                    aspect-ratio:${
                      video.frameSize === 'Square 1:1'
                        ? '1 / 1'
                        : video.frameSize === 'Portrait 9:16'
                        ? '9 / 16'
                        : '16 / 9'
                    };
                  "
                >

                  <video
                    src="${escapeAttr(video.videoUrl)}"
                    controls
                    playsinline
                    preload="metadata"
                    style="
                      width:100%;
                      height:100%;
                      display:block;
                      object-fit:contain;
                      background:#000;
                    "
                  ></video>

                </div>

              </div>

              <!-- DOWNLOAD -->

              <div class="after-gen-actions">

                <button
                  class="btn btn-primary"
                  id="library-download-btn"
                >
                  Download
                </button>

              </div>

            </div>


            <!-- RIGHT: DETAILS -->
            <div class="settings-box library-details">

              <p class="settings-box-title">
                VIDEO DETAILS
              </p>

              <!-- PROMPT -->

              <div class="library-detail-item">

                <label class="field-label">
                  Product name / prompt
                </label>

                <div class="library-detail-value prompt-value">
                  ${escapeHtml(
                    video.prompt ||
                    video.productName ||
                    'No prompt saved'
                  )}
                </div>

              </div>


              <!-- DURATION -->

              <div class="library-detail-item">

                <label class="field-label">
                  Duration
                </label>

                <div class="library-detail-value">
                  ${escapeHtml(
                    String(video.duration || '')
                  )} seconds
                </div>

              </div>


              <!-- FRAME SIZE -->

              <div class="library-detail-item">

                <label class="field-label">
                  Frame size
                </label>

                <div class="library-detail-value">
                  ${escapeHtml(
                    video.frameSize || '16:9'
                  )}
                </div>

              </div>


              <!-- AUDIO -->

              <div class="library-detail-item">

                <label class="field-label">
                  Audio
                </label>

                <div class="library-detail-value">
                  ${escapeHtml(
                    video.audio || 'None'
                  )}
                </div>

              </div>


              <!-- CLIPS -->

              ${
                Array.isArray(video.clips) &&
                video.clips.length
                  ? video.clips
                      .map(
                        (clip, index) => `
                          <div class="library-clip">

                            <p class="library-clip-title">
                              CLIP ${index + 1}
                            </p>

                            <div class="library-clip-fields">

                              <div>
                                <span class="field-label">
                                  Camera motion
                                </span>

                                <div class="library-detail-value">
                                  ${escapeHtml(
                                    clip.cameraMotion || ''
                                  )}
                                </div>
                              </div>


                              <div>
                                <span class="field-label">
                                  Product movement
                                </span>

                                <div class="library-detail-value">
                                  ${escapeHtml(
                                    clip.productMovement || ''
                                  )}
                                </div>
                              </div>


                              <div>
                                <span class="field-label">
                                  Lighting
                                </span>

                                <div class="library-detail-value">
                                  ${escapeHtml(
                                    clip.lighting || ''
                                  )}
                                </div>
                              </div>


                              ${
                                clip.effect
                                  ? `
                                    <div>
                                      <span class="field-label">
                                        Effect
                                      </span>

                                      <div class="library-detail-value">
                                        ${escapeHtml(
                                          clip.effect
                                        )}
                                      </div>
                                    </div>
                                  `
                                  : ''
                              }


                              ${
                                clip.background
                                  ? `
                                    <div>
                                      <span class="field-label">
                                        Background
                                      </span>

                                      <div class="library-detail-value">
                                        ${escapeHtml(
                                          clip.background
                                        )}
                                      </div>
                                    </div>
                                  `
                                  : ''
                              }


                              ${
                                clip.backgroundMotion
                                  ? `
                                    <div>
                                      <span class="field-label">
                                        Background motion
                                      </span>

                                      <div class="library-detail-value">
                                        ${escapeHtml(
                                          clip.backgroundMotion
                                        )}
                                      </div>
                                    </div>
                                  `
                                  : ''
                              }


                              ${
                                clip.textOnVideo
                                  ? `
                                    <div>
                                      <span class="field-label">
                                        Text on video
                                      </span>

                                      <div class="library-detail-value">
                                        ${escapeHtml(
                                          clip.textOnVideo
                                        )}
                                      </div>
                                    </div>
                                  `
                                  : ''
                              }


                              ${
                                clip.creativeDirection
                                  ? `
                                    <div>
                                      <span class="field-label">
                                        Additional creative direction
                                      </span>

                                      <div class="library-detail-value">
                                        ${escapeHtml(
                                          clip.creativeDirection
                                        )}
                                      </div>
                                    </div>
                                  `
                                  : ''
                              }

                            </div>

                          </div>
                        `
                      )
                      .join('')
                  : ''
              }

            </div>

          </div>


      </div>
    `
  }

  // ============================================================
  // NORMAL LIBRARY GRID
  // ============================================================

  return `
    <div class="app-shell">

      ${renderSidebar('library')}

      <div style="
        flex:1;
        padding:36px;
        overflow:auto;
      ">

        ${
          state.isGuest &&
          !state.guestBannerDismissed
            ? `
              <div class="library-banner">

                <div style="
                  display:flex;
                  align-items:center;
                  gap:10px;
                ">

                  <span style="
                    color:var(--accent);
                  ">
                    ●
                  </span>

                  <span style="
                    font-size:12px;
                  ">
                    Browsing as guest — sign up to keep your videos and templates
                  </span>

                </div>

                <div style="
                  display:flex;
                  align-items:center;
                  gap:10px;
                ">

                  <button
                    class="btn btn-primary"
                    id="banner-signup"
                    style="
                      padding:7px 14px;
                      font-size:11px;
                    "
                  >
                    Sign up
                  </button>

                  <span
                    id="banner-dismiss"
                    style="
                      cursor:pointer;
                      color:var(--text-muted);
                    "
                  >
                    ✕
                  </span>

                </div>

              </div>
            `
            : ''
        }

        <h1 style="
          font-size:26px;
          margin-bottom:6px;
        ">
          Library
        </h1>

        <p style="
          color:var(--text-muted);
          font-size:13px;
          margin:0 0 24px;
        ">
          ${state.videos.length} video(s) saved
        </p>

        ${
          state.videos.length === 0
            ? `
              <div style="
                text-align:center;
                padding:60px 20px;
                border:1px dashed var(--border);
                border-radius:10px;
                max-width:360px;
              ">

                <div style="
                  font-size:24px;
                ">
                  🎬
                </div>

                <p style="
                  margin:12px 0 4px;
                  color:var(--text-secondary);
                ">
                  No videos yet
                </p>

                <p style="
                  margin:0 0 16px;
                  font-size:12px;
                  color:var(--text-muted);
                ">
                  Create your first video and it'll appear here.
                </p>

                <button
                  class="btn btn-primary"
                  id="empty-new-project"
                  style="
                    padding:8px 16px;
                  "
                >
                  + Create new project
                </button>

              </div>
            `
            : `
              <div class="thumb-grid">

                ${state.videos
                  .map(
                    (video, index) => `
                      <div
                        class="thumb"
                        data-library-video="${index}"
                        style="cursor:pointer;"
                      >

                        ${
                          video.thumbnail
                            ? `
                              <img
                                src="${escapeAttr(
                                  video.thumbnail
                                )}"
                                alt="${escapeAttr(
                                  video.productName ||
                                  'Generated video'
                                )}"
                              />
                            `
                            : `
                              <video
                                src="${escapeAttr(video.videoUrl)}"
                                muted
                                autoplay
                                loop
                                playsinline
                                preload="auto"
                                style="
                                  width:100%;
                                  height:100%;
                                  display:block;
                                  object-fit:cover;
                                  background:#000;
                                "
                              ></video>
                            `
                        }

                      </div>
                    `
                  )
                  .join('')}

                <div
                  class="thumb add"
                  id="grid-new-project"
                >
                  +
                </div>

              </div>
            `
        }

      </div>

    </div>
  `
}


// ============================================================================
// SETTINGS
// ============================================================================

function renderSettings() {
  return `
    <div class="app-shell">

      ${renderSidebar('settings')}

      <div style="
        flex:1;
        padding:36px;
        max-width:480px;
        overflow:auto;
      ">

        <h1 style="
          font-size:26px;
          margin-bottom:20px;
        ">
          Settings
        </h1>

        <div style="
          display:flex;
          align-items:center;
          gap:12px;
          background:var(--surface);
          border-radius:10px;
          padding:14px;
          margin-bottom:20px;
        ">

          <div
            class="avatar"
            style="
              width:40px;
              height:40px;
            "
          >
            ${
              state.isGuest
                ? 'G'
                : escapeHtml(
                    (state.userName || 'U')
                      .slice(0, 2)
                      .toUpperCase()
                  )
            }
          </div>

          <div>

            <p style="
              margin:0;
              font-size:13px;
            ">
              ${
                state.isGuest
                  ? 'Guest'
                  : escapeHtml(state.userName)
              }
            </p>

            <p style="
              margin:0;
              font-size:11px;
              color:var(--text-muted);
            ">
              ${
                state.isGuest
                  ? 'Not signed in'
                  : escapeHtml(state.userEmail)
              }
            </p>

          </div>

        </div>

        <p class="settings-group-title">
          Account
        </p>

        <div class="settings-list">

          <div class="settings-row">

            <span>
              Password and security
            </span>

            <span>
              ›
            </span>

          </div>

        </div>

        <p class="settings-group-title">
          Preferences
        </p>

        <div class="settings-list">

          <div class="settings-row">

            <span>
              Notifications
            </span>

            <div
              class="toggle"
              id="toggle-notif"
            >
              <div class="toggle-dot"></div>
            </div>

          </div>

          <div class="settings-row">

            <span>
              Language
            </span>

            <span style="
              color:var(--text-muted);
            ">
              English
            </span>

          </div>

          <div class="settings-row">

            <span>
              About
            </span>

            <span>
              ›
            </span>

          </div>

        </div>

        <p class="settings-group-title">
          Support
        </p>

        <div class="settings-list">

          <div class="settings-row">

            <span>
              Help center
            </span>

            <span>
              ›
            </span>

          </div>

          <div
            class="settings-row"
            id="logout-btn"
            style="
              cursor:pointer;
            "
          >
            <span style="
              color:var(--error);
            ">
              Log out
            </span>
          </div>

        </div>

      </div>

    </div>
  `
}

// ============================================================================
// VALIDATION / HELPERS
// ============================================================================

function getNameError() {
  const name =
    sanitizeText(state.productName)

  if (name.trim().length === 0) {
    return 'Product name is required.'
  }

  if (!isPlausibleProductName(name)) {
    return 'That doesn\'t look like a product name. Try something like "Flower Bouquet."'
  }

  return ''
}

function sanitizeText(input) {
  return String(input || '')
    .replace(/<[^>]*>/g, '')
    .replace(/[<>]/g, '')
    .trim()
}

function isPlausibleProductName(name) {
  const clean =
    String(name || '').trim()

  if (clean.length < 2) {
    return false
  }

  if (!/[aeiouAEIOU]/.test(clean)) {
    return false
  }

  const consonantRun =
    /[^aeiouAEIOU\s]{5,}/.test(clean)

  if (consonantRun) {
    return false
  }

  return true
}

function escapeHtml(str) {
  return String(str || '').replace(
    /[&<>"']/g,
    char =>
      ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;',
      }[char])
  )
}

function escapeAttr(str) {
  return escapeHtml(str)
}

function apiFrameSize() {
  if (
    state.frameSize === 'Square 1:1'
  ) {
    return '1:1'
  }

  if (
    state.frameSize === 'Landscape 16:9'
  ) {
    return '16:9'
  }

  if (
    state.frameSize === 'Portrait 9:16'
  ) {
    return '9:16'
  }

  return '16:9'
}

function numericDuration() {
  if (
    state.duration === '10 seconds'
  ) {
    return 10
  }

  if (
    state.duration === '15 seconds'
  ) {
    return 15
  }

  return 5
}

function videoAspectRatio() {
  if (
    state.frameSize.startsWith('Square')
  ) {
    return '1 / 1'
  }

  if (
    state.frameSize.startsWith('Portrait')
  ) {
    return '9 / 16'
  }

  return '16 / 9'
}

function backendShots() {
  const total =
    clipsForDuration(state.duration)

  return state.clips
    .slice(0, total)
    .map((clip, index) => ({
      shot: index + 1,

      cameraMotion:
        clip.cameraMotion || '',

      // Python expects productMotion.
      productMotion:
        clip.productMovement || '',

      lighting:
        clip.lighting || '',

      effect:
        sanitizeText(clip.effect),

      background:
        sanitizeText(clip.background),

      backgroundMotion:
        sanitizeText(
          clip.backgroundMotion
        ),

      textOnVideo:
        sanitizeText(
          clip.textOnVideo
        ),

      // Python expects additionalPrompt.
      additionalPrompt:
        sanitizeText(
          clip.creativeDirection
        ),
    }))
}

function resetGenerationState() {
  stopFakeProgress()

  if (generationController) {
    generationController = null
  }

  state.status = 'idle'
  state.progress = 0
  state.generatedVideo = null
  state.savedToLibrary = false
  state.generationError = ''
  state.generationWarning = ''
}

// ============================================================================
// EVENT HANDLERS
// ============================================================================

function attachHandlers() {
  const $ =
    selector =>
      document.querySelector(selector)

  const $$ =
    selector =>
      document.querySelectorAll(selector)

  // --------------------------------------------------------------------------
  // LANDING
  // --------------------------------------------------------------------------

  $('#start-creating')
    ?.addEventListener(
      'click',
      () => {
        state.screen = 'auth'
        render()
      }
    )

  // --------------------------------------------------------------------------
  // AUTH
  // --------------------------------------------------------------------------

  $$('.auth-tab')
    .forEach(element => {
      element.addEventListener(
        'click',
        () => {
          state.authMode =
            element.dataset.authMode

          render()
        }
      )
    })

  $('#auth-guest')
    ?.addEventListener(
      'click',
      () => {
        state.isGuest = true
        state.userName = ''
        state.userEmail = ''
        state.screen = 'create'

        render()
      }
    )

  $('#auth-google')
    ?.addEventListener(
      'click',
      () => {
        state.isGuest = false
        state.userName = 'Google User'
        state.userEmail = 'user@gmail.com'
        state.screen = 'create'

        render()
      }
    )

  $('#auth-submit')
    ?.addEventListener(
      'click',
      () => {
        const email =
          $('#auth-email')?.value.trim() || ''

        const password =
          $('#auth-password')?.value || ''

        const errorElement =
          $('#auth-error')

        if (!errorElement) return

        if (
          !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(
            email
          )
        ) {
          errorElement.textContent =
            'Enter a valid email address.'

          errorElement.classList.remove(
            'hidden'
          )

          return
        }

        if (password.length < 8) {
          errorElement.textContent =
            'Password must be at least 8 characters.'

          errorElement.classList.remove(
            'hidden'
          )

          return
        }

        if (
          state.authMode === 'signup'
        ) {
          const confirm =
            $('#auth-confirm')?.value || ''

          if (
            password !== confirm
          ) {
            errorElement.textContent =
              'Passwords do not match.'

            errorElement.classList.remove(
              'hidden'
            )

            return
          }
        }

        state.isGuest = false

        state.userName =
          email.split('@')[0]

        state.userEmail =
          email

        state.screen =
          'create'

        render()
      }
    )

  // --------------------------------------------------------------------------
  // SIDEBAR NAV
  // --------------------------------------------------------------------------

  $$('[data-nav]')
    .forEach(element => {
      element.addEventListener(
        'click',
        () => {
          if (
            state.status === 'processing'
          ) {
            return
          }

          state.screen =
            element.dataset.nav

          render()
        }
      )
    })


  // --------------------------------------------------------------------------
  // IMAGE UPLOAD
  // --------------------------------------------------------------------------

  const dropzone =
    $('#dropzone')

  dropzone
    ?.addEventListener(
      'click',
      () => {
        if (state.currentClip > 0) {
          return
        }

        if (
          state.status === 'processing'
        ) {
          return
        }

        $('#file-input')?.click()
      }
    )

  $('#file-input')
    ?.addEventListener(
      'change',
      event => {
        const file =
          event.target.files?.[0]

        if (file) {
          handleImageFile(file)
        }
      }
    )

  dropzone
    ?.addEventListener(
      'dragover',
      event => {
        if (state.currentClip > 0) {
          return
        }

        event.preventDefault()

        dropzone.classList.add(
          'dragging'
        )
      }
    )

  dropzone
    ?.addEventListener(
      'dragleave',
      () => {
        dropzone.classList.remove(
          'dragging'
        )
      }
    )

  dropzone
    ?.addEventListener(
      'drop',
      event => {
        if (state.currentClip > 0) {
          return
        }

        event.preventDefault()

        dropzone.classList.remove(
          'dragging'
        )

        const file =
          event.dataTransfer?.files?.[0]

        if (file) {
          handleImageFile(file)
        }
      }
    )

  // --------------------------------------------------------------------------
  // PRODUCT NAME
  // --------------------------------------------------------------------------

  $('#product-name')
    ?.addEventListener(
      'input',
      event => {
        state.productName =
          event.target.value
      }
    )

  $('#product-name')
    ?.addEventListener(
      'blur',
      event => {
        state.productName =
          event.target.value

        state.productNameTouched =
          true

        render()
      }
    )

  // --------------------------------------------------------------------------
  // DURATION
  // --------------------------------------------------------------------------

  $$('[data-duration]')
    .forEach(element => {
      element.addEventListener(
        'click',
        () => {
          if (
            state.currentClip > 0 ||
            state.status === 'processing'
          ) {
            return
          }

          state.duration =
            element.dataset.duration

          const total =
            clipsForDuration(
              state.duration
            )

          while (
            state.clips.length < total
          ) {
            state.clips.push(
              defaultClip()
            )
          }

          state.clips =
            state.clips.slice(
              0,
              total
            )

          state.currentClip = 0

          resetGenerationState()

          render()
        }
      )
    })

  // --------------------------------------------------------------------------
  // FRAME SIZE
  // --------------------------------------------------------------------------

  $$('[data-frame]')
    .forEach(element => {
      element.addEventListener(
        'click',
        () => {
          if (
            state.currentClip > 0 ||
            state.status === 'processing'
          ) {
            return
          }

          state.frameSize =
            element.dataset.frame

          resetGenerationState()

          render()
        }
      )
    })

  // --------------------------------------------------------------------------
  // AUDIO
  // --------------------------------------------------------------------------

  $('#audio-upload')
    ?.addEventListener(
      'click',
      () => {
        if (
          state.status === 'processing'
        ) {
          return
        }

        $('#audio-input')?.click()
      }
    )

  $('#audio-input')
    ?.addEventListener(
      'change',
      event => {
        const file =
          event.target.files?.[0]

        if (!file) return

        state.audioFile =
          file

        state.audioFileName =
          file.name

        state.generationWarning = ''

        render()
      }
    )

  $('#remove-audio-file')
    ?.addEventListener(
      'click',
      () => {
        state.audioFile = null
        state.audioFileName = ''

        render()
      }
    )

  // --------------------------------------------------------------------------
  // DROPDOWNS
  // --------------------------------------------------------------------------

  $$('[data-dropdown-toggle]')
    .forEach(element => {
      element.addEventListener(
        'click',
        event => {
          event.stopPropagation()

          if (
            state.status === 'processing'
          ) {
            return
          }

          const id =
            element.dataset.dropdownToggle

          if (
            state.openDropdown === id
          ) {
            state.openDropdown = null
            closeDropdownMenus()
            return
          }

          state.openDropdown = id

          openDropdownMenu(
            id,
            element
          )
        }
      )
    })

  document.addEventListener(
    'click',
    () => {
      if (
        state.openDropdown
      ) {
        state.openDropdown = null

        closeDropdownMenus()
      }
    },
    {
      once: true,
    }
  )

  // --------------------------------------------------------------------------
  // CLIP TEXT FIELDS
  // --------------------------------------------------------------------------

  const currentClip = () =>
    state.clips[
      state.currentClip
    ]

  $('#clip-effect')
    ?.addEventListener(
      'input',
      event => {
        currentClip().effect =
          event.target.value
      }
    )

  $('#clip-background')
    ?.addEventListener(
      'input',
      event => {
        currentClip().background =
          event.target.value
      }
    )

  $('#clip-background-motion')
    ?.addEventListener(
      'input',
      event => {
        currentClip().backgroundMotion =
          event.target.value
      }
    )

  $('#clip-text')
    ?.addEventListener(
      'input',
      event => {
        currentClip().textOnVideo =
          event.target.value
      }
    )

  $('#clip-direction')
    ?.addEventListener(
      'input',
      event => {
        currentClip().creativeDirection =
          event.target.value
      }
    )

  // --------------------------------------------------------------------------
  // CLIP NAVIGATION
  // --------------------------------------------------------------------------

  $('#clip-prev')
    ?.addEventListener(
      'click',
      () => {
        if (
          state.status === 'processing'
        ) {
          return
        }

        if (
          state.currentClip > 0
        ) {
          state.currentClip--

          render()
        }
      }
    )

  $('#clip-next')
    ?.addEventListener(
      'click',
      () => {
        if (
          state.status === 'processing'
        ) {
          return
        }

        const total =
          clipsForDuration(
            state.duration
          )

        if (
          state.currentClip <
          total - 1
        ) {
          state.currentClip++

          render()
        }
      }
    )

  // --------------------------------------------------------------------------
  // GENERATE
  // --------------------------------------------------------------------------

  $('#generate-btn')
    ?.addEventListener(
      'click',
      handleGenerate
    )

  $('#retry-btn')
    ?.addEventListener(
      'click',
      () => {
        state.status = 'idle'
        state.progress = 0
        state.generationError = ''
        state.generationWarning = ''

        render()
      }
    )

  $('#cancel-btn')
    ?.addEventListener(
      'click',
      handleCancelGeneration
    )

  // --------------------------------------------------------------------------
  // SAVE
  // --------------------------------------------------------------------------

  // --------------------------------------------------------------------------
// SAVE
// --------------------------------------------------------------------------

$('#save-btn')
?.addEventListener(
  'click',
  async () => {

    if (!state.generatedVideo) {
      return
    }

    if (state.savedToLibrary) {
      return
    }

    const video = state.generatedVideo

    if (!video.videoUrl) {
      console.error(
        'Cannot save video: videoUrl is missing.'
      )

      alert(
        'Cannot save this video because the video URL is missing.'
      )

      return
    }

    const formData = new FormData()

    formData.append(
      'video_url',
      video.videoUrl
    )

    formData.append(
      'filename',
      video.filename ||
      `vibify-${Date.now()}.mp4`
    )

    formData.append(
      'product_name',
      state.productName || ''
    )

    formData.append(
      'frame_size',
      state.frameSize || ''
    )

    formData.append(
      'duration',
      String(
        numericDuration()
      )
    )

    formData.append(
      'audio',
      state.audio || ''
    )

    formData.append(
      'shots',
      JSON.stringify(
        state.clips.map(clip => ({
          ...clip
        }))
      )
    )

    try {

      const response =
        await fetch(
          '/api/library/save',
          {
            method: 'POST',
            body: formData
          }
        )

      const result =
        await response.json()

      if (!response.ok) {
        throw new Error(
          result?.detail ||
          `Save failed with HTTP ${response.status}`
        )
      }

      if (!result?.success) {
        throw new Error(
          result?.detail ||
          'Could not save video.'
        )
      }

      // Use the video returned by FastAPI.
      // This is important because the backend
      // gives us the actual saved library record.
      const savedVideo =
        normalizeLibraryVideo(
          result.video
        )

      if (savedVideo) {

        // Remove an existing copy with
        // the same filename.
        state.videos =
          state.videos.filter(
            existing =>
              existing.filename !==
              savedVideo.filename
          )

        // Put newest video at the top.
        state.videos.unshift(
          savedVideo
        )
      }

      state.savedToLibrary = true

      render()

      console.log(
        'Video saved to backend library:',
        savedVideo
      )

    } catch (error) {

      console.error(
        'Could not save video to library:',
        error
      )

      alert(
        `Could not save video to Library.\n\n${error.message}`
      )
    }
  }
)


  // --------------------------------------------------------------------------
  // DOWNLOAD
  // --------------------------------------------------------------------------

  $('#download-btn')
    ?.addEventListener(
      'click',
      handleDownload
    )

  // --------------------------------------------------------------------------
  // GENERATE AGAIN
  // --------------------------------------------------------------------------

  $('#generate-again-btn')
    ?.addEventListener(
      'click',
      async () => {

        // Don't allow another generation while one
        // is already running.
        if (
          state.status === 'processing'
        ) {
          return
        }

        // Make sure fake progress from the previous
        // generation is completely stopped.
        stopFakeProgress()

        // Clear the previous generation result.
        state.generatedVideo = null
        state.savedToLibrary = false

        state.status = 'idle'
        state.progress = 0

        state.generationError = ''
        state.generationWarning = ''

        // IMPORTANT:
        // Do NOT reset:
        // - product image
        // - product name
        // - duration
        // - frame size
        // - audio
        // - clips
        // - camera motion
        // - product movement
        // - lighting
        // - effect
        // - background
        // - background motion
        // - text on video
        // - creative direction

        render()

        // Wait until the UI has updated, then
        // immediately generate another version.
        await new Promise(
          resolve =>
            requestAnimationFrame(resolve)
        )

        handleGenerate()
      }
    )



  // --------------------------------------------------------------------------
  // ONBOARDING
  // --------------------------------------------------------------------------

  $('#ob-next')
    ?.addEventListener(
      'click',
      () => {
        if (
          state.obStep + 1 >=
          ONBOARDING_STEPS.length
        ) {
          state.onboardingDone = true
        } else {
          state.obStep++
        }

        render()
      }
    )

  $('#ob-skip')
    ?.addEventListener(
      'click',
      () => {
        state.onboardingDone = true

        render()
      }
    )

  // --------------------------------------------------------------------------
  // LIBRARY
  // --------------------------------------------------------------------------

  $$('[data-library-video]')
  .forEach(element => {
    element.addEventListener(
      'click',
      () => {
        const index =
          Number(element.dataset.libraryVideo)

        const video =
          state.videos[index]

        if (!video) {
          return
        }

        state.selectedLibraryVideo = video

        render()
      }
    )
  })

$('#library-back')
  ?.addEventListener(
    'click',
    () => {
      state.selectedLibraryVideo = null
      render()
    }
  )

    $('#library-download-btn')
  ?.addEventListener(
    'click',
    async () => {
      if (!state.selectedLibraryVideo) {
        return
      }

      const video =
        state.selectedLibraryVideo

      if (!video.videoUrl) {
        return
      }

      const filename =
        video.filename ||
        'vibify-video.mp4'

      try {
        const response =
          await fetch(
            video.videoUrl
          )

        if (!response.ok) {
          throw new Error(
            `Download failed with HTTP ${response.status}.`
          )
        }

        const blob =
          await response.blob()

        const blobUrl =
          URL.createObjectURL(blob)

        const anchor =
          document.createElement('a')

        anchor.href =
          blobUrl

        anchor.download =
          filename

        document.body.appendChild(
          anchor
        )

        anchor.click()

        anchor.remove()

        setTimeout(
          () => {
            URL.revokeObjectURL(
              blobUrl
            )
          },
          1000
        )
      } catch (error) {
        console.warn(
          'Library download failed; using direct link.',
          error
        )

        const anchor =
          document.createElement('a')

        anchor.href =
          video.videoUrl

        anchor.download =
          filename

        anchor.target =
          '_blank'

        document.body.appendChild(
          anchor
        )

        anchor.click()

        anchor.remove()
      }
    }
  )
  
  $('#banner-signup')
    ?.addEventListener(
      'click',
      () => {
        state.screen = 'auth'
        state.authMode = 'signup'

        render()
      }
    )

  $('#banner-dismiss')
    ?.addEventListener(
      'click',
      () => {
        state.guestBannerDismissed =
          true

        render()
      }
    )

  $('#empty-new-project')
    ?.addEventListener(
      'click',
      () => {
        state.screen = 'create'

        render()
      }
    )

  $('#grid-new-project')
    ?.addEventListener(
      'click',
      () => {
        state.screen = 'create'

        render()
      }
    )

  // --------------------------------------------------------------------------
  // SETTINGS
  // --------------------------------------------------------------------------

  $('#toggle-notif')
    ?.addEventListener(
      'click',
      event => {
        event.target
          .closest('.toggle')
          ?.classList.toggle('off')
      }
    )

  $('#logout-btn')
    ?.addEventListener(
      'click',
      () => {
        state.isGuest = false
        state.userName = ''
        state.userEmail = ''

        state.screen = 'auth'
        state.authMode = 'login'

        render()
      }
    )
}

// ============================================================================
// IMAGE FILE
// ============================================================================

function handleImageFile(file) {
  if (!file) return

  const allowedTypes = [
    'image/jpeg',
    'image/png',
    'image/webp',
  ]

  if (
    file.type &&
    !allowedTypes.includes(file.type)
  ) {
    state.imageSizeError =
      'Please upload a JPG, PNG or WEBP image.'

    state.imageFile = null
    state.imageDataUrl = null

    render()

    return
  }

  if (
    file.size >
    20 * 1024 * 1024
  ) {
    state.imageSizeError =
      'File exceeds 20 MB limit.'

    state.imageFile = null
    state.imageDataUrl = null

    render()

    return
  }

  state.imageSizeError = ''
  state.imageFile = file
  state.generatedVideo = null
  state.status = 'idle'
  state.progress = 0
  state.savedToLibrary = false
  state.generationError = ''
  state.generationWarning = ''

  const reader =
    new FileReader()

  reader.onload =
    event => {
      state.imageDataUrl =
        event.target.result

      render()
    }

  reader.onerror =
    () => {
      state.imageSizeError =
        'Could not read the selected image.'

      state.imageFile = null
      state.imageDataUrl = null

      render()
    }

  reader.readAsDataURL(file)
}

// ============================================================================
// GENERATE
// ============================================================================

async function handleGenerate() {
  if (
    state.status === 'processing'
  ) {
    return
  }

  state.submitAttempted = true

  const nameError =
    getNameError()

  if (
    !state.imageFile ||
    nameError
  ) {
    render()
    return
  }

  const duration =
    numericDuration()

  const shots =
    backendShots()

  if (
    shots.length !==
    duration / 5
  ) {
    state.status = 'failed'

    state.generationError =
      `Internal clip count mismatch. ` +
      `Expected ${duration / 5}, got ${shots.length}.`

    render()

    return
  }

  state.status =
    'processing'

  state.progress = 4

  state.generatedVideo = null

  state.savedToLibrary = false

  state.generationError = ''

  state.generationWarning = ''

  render()

  startFakeProgress()

  generationController =
    new AbortController()

  const formData =
    new FormData()

  formData.append(
  'product_name',
  state.productName || ''
)

  formData.append(
    'prompt',
    state.productName || ''
)

  formData.append(
    'frame_size',
    apiFrameSize()
  )

  formData.append(
    'duration',
    String(duration)
  )

  formData.append(
    'shots',
    JSON.stringify(shots)
  )

  formData.append(
    'product_image',
    state.imageFile,
    state.imageFile.name ||
      'product.png'
  )

  // Audio preset.
  formData.append(
    'audio',
    state.audio || ''
  )

  // User uploaded audio takes priority.
  if (state.audioFile) {
    formData.append(
      'audio_file',
      state.audioFile,
      state.audioFile.name ||
        'audio.mp3'
    )
  }

  try {
    const response =
      await fetch(
        '/generate',
        {
          method: 'POST',
          body: formData,
          signal:
            generationController.signal,
        }
      )

    let result = null

    try {
      result =
        await response.json()
    } catch (error) {
      throw new Error(
        `Server returned HTTP ${response.status}, but the response was not valid JSON.`
      )
    }

    if (!response.ok) {
      throw new Error(
        extractBackendError(
          result,
          response.status
        )
      )
    }

    if (!result?.success) {
      throw new Error(
        result?.detail ||
          'Video generation failed.'
      )
    }

    if (!result.video_url) {
      throw new Error(
        'Generation completed but the backend did not return video_url.'
      )
    }

    stopFakeProgress()

    state.progress = 100

    state.status = 'done'

    state.generatedVideo = {
      id:
        result.id ||
        Date.now().toString(),

      videoUrl:
        result.video_url,

      filename:
        result.filename ||
        `vibify-${Date.now()}.mp4`,

      thumbnail:
        state.imageDataUrl,

      productName:
        sanitizeText(
          state.productName
        ),

      duration,

      frameSize:
        state.frameSize,

      audio:
        state.audio,

      audioFileName:
        state.audioFileName,

      audioApplied:
        !!result.audio_applied,

      shots:
        result.shots || [],

      shotChain:
        result.shot_chain || [],

      createdAt:
        new Date(),
    }

    if (
      result.audio_warning
    ) {
      state.generationWarning =
        result.audio_warning
    }

    generationController = null

    render()
  } catch (error) {
    stopFakeProgress()

    const wasAborted =
      error?.name ===
      'AbortError'

    generationController = null

    if (wasAborted) {
      state.status = 'idle'

      state.progress = 0

      state.generationError = ''

      state.generationWarning =
        'Generation cancelled.'

      render()

      return
    }

    console.error(
      'Vibify generation error:',
      error
    )

    state.status = 'failed'

    state.progress = 0

    state.generationError =
      error?.message ||
      'Video generation failed.'

    render()
  }
}

// ============================================================================
// BACKEND ERROR
// ============================================================================

function extractBackendError(
  result,
  status
) {
  if (!result) {
    return `Request failed with HTTP ${status}.`
  }

  if (
    typeof result.detail ===
    'string'
  ) {
    return result.detail
  }

  if (
    result.detail &&
    typeof result.detail ===
      'object'
  ) {
    if (
      typeof result.detail.message ===
      'string'
    ) {
      let message =
        result.detail.message

      if (
        result.detail.error
      ) {
        message +=
          `\n${result.detail.error}`
      }

      if (
        result.detail.response
      ) {
        message +=
          `\n${JSON.stringify(
            result.detail.response
          )}`
      }

      return message
    }

    try {
      return JSON.stringify(
        result.detail,
        null,
        2
      )
    } catch {
      return `Request failed with HTTP ${status}.`
    }
  }

  if (
    typeof result.message ===
    'string'
  ) {
    return result.message
  }

  return `Request failed with HTTP ${status}.`
}

// ============================================================================
// PROGRESS
// ============================================================================

function startFakeProgress() {
  stopFakeProgress()

  progressTimer =
    setInterval(() => {
      if (
        state.status !==
        'processing'
      ) {
        stopFakeProgress()
        return
      }

      if (
        state.progress >= 92
      ) {
        return
      }

      const remaining =
        92 - state.progress

      const step =
        Math.max(
          0.15,
          Math.random() *
            Math.min(
              1.5,
              remaining * 0.08
            )
        )

      state.progress =
        Math.min(
          92,
          state.progress + step
        )

      updateProgressUI()
    }, 1000)
}

function stopFakeProgress() {
  if (progressTimer) {
    clearInterval(progressTimer)

    progressTimer = null
  }
}

function updateProgressUI() {
  const fill =
    document.querySelector(
      '.progress-fill'
    )

  const percentage =
    document.querySelector(
      '.progress-pct'
    )

  const videoText =
    document.querySelector(
      '.video-box p'
    )

  if (fill) {
    fill.style.width =
      `${state.progress}%`
  }

  if (percentage) {
    percentage.textContent =
      `${Math.round(
        state.progress
      )}%`
  }

  if (
    videoText &&
    state.status === 'processing'
  ) {
    videoText.textContent =
      `Generating your video… ${Math.round(
        state.progress
      )}%`
  }
}

// ============================================================================
// CANCEL
// ============================================================================

async function handleCancelGeneration() {
  if (
    state.status !== 'processing'
  ) {
    return
  }

  stopFakeProgress()

  if (generationController) {
    generationController.abort()
  }

  try {
    await fetch(
      '/interrupt',
      {
        method: 'POST',
      }
    )
  } catch (error) {
    console.warn(
      'Could not call backend interrupt endpoint:',
      error
    )
  }

  generationController = null

  state.status = 'idle'

  state.progress = 0

  state.generationError = ''

  state.generationWarning =
    'Generation cancelled.'

  render()
}

// ============================================================================
// DOWNLOAD
// ============================================================================

async function handleDownload() {
  if (
    !state.generatedVideo?.videoUrl
  ) {
    return
  }

  const filename =
    state.generatedVideo.filename ||
    `${(
      state.generatedVideo
        .productName ||
      'vibify-video'
    )
      .replace(
        /[^a-zA-Z0-9-_]+/g,
        '-'
      )
      .replace(
        /^-+|-+$/g,
        ''
      )
      .toLowerCase()}.mp4`

  try {
    const response =
      await fetch(
        state.generatedVideo.videoUrl
      )

    if (!response.ok) {
      throw new Error(
        `Download failed with HTTP ${response.status}.`
      )
    }

    const blob =
      await response.blob()

    const blobUrl =
      URL.createObjectURL(blob)

    const anchor =
      document.createElement('a')

    anchor.href =
      blobUrl

    anchor.download =
      filename

    document.body.appendChild(
      anchor
    )

    anchor.click()

    anchor.remove()

    setTimeout(
      () => {
        URL.revokeObjectURL(
          blobUrl
        )
      },
      1000
    )
  } catch (error) {
    console.warn(
      'Fetch download failed; using direct link.',
      error
    )

    const anchor =
      document.createElement('a')

    anchor.href =
      state.generatedVideo.videoUrl

    anchor.download =
      filename

    anchor.target =
      '_blank'

    document.body.appendChild(
      anchor
    )

    anchor.click()

    anchor.remove()
  }
}

// ============================================================================
// DROPDOWNS
// ============================================================================

function dropdownOptionsFor(id) {
  if (id === 'audio') {
    return AUDIO_OPTIONS
  }

  if (id === 'cameraMotion') {
    return CAMERA_MOTION_OPTIONS
  }

  if (id === 'productMovement') {
    return PRODUCT_MOVEMENT_OPTIONS
  }

  if (id === 'lighting') {
    return LIGHTING_OPTIONS
  }

  return []
}

function currentValueFor(id) {
  const clip =
    state.clips[
      state.currentClip
    ]

  if (id === 'audio') {
    return state.audio
  }

  if (id === 'cameraMotion') {
    return clip.cameraMotion
  }

  if (
    id === 'productMovement'
  ) {
    return clip.productMovement
  }

  if (id === 'lighting') {
    return clip.lighting
  }

  return ''
}

function setValueFor(
  id,
  value
) {
  const clip =
    state.clips[
      state.currentClip
    ]

  if (id === 'audio') {
    state.audio = value
  } else if (
    id === 'cameraMotion'
  ) {
    clip.cameraMotion = value
  } else if (
    id === 'productMovement'
  ) {
    clip.productMovement = value
  } else if (
    id === 'lighting'
  ) {
    clip.lighting = value
  }
}

function openDropdownMenu(
  id,
  fieldElement
) {
  closeDropdownMenus()

  const options =
    dropdownOptionsFor(id)

  const current =
    currentValueFor(id)

  const menu =
    document.createElement(
      'div'
    )

  menu.className =
    'dropdown-menu'

  menu.id =
    'active-dropdown-menu'

  menu.innerHTML =
    options
      .map(
        option => `
          <div
            class="
              dropdown-option
              ${
                option === current
                  ? 'selected'
                  : ''
              }
            "
            data-dropdown-option="${escapeAttr(
              option
            )}"
          >
            ${escapeHtml(option)}
          </div>
        `
      )
      .join('')

  fieldElement
    .closest('.dropdown')
    ?.appendChild(menu)

  menu
    .querySelectorAll(
      '[data-dropdown-option]'
    )
    .forEach(optionElement => {
      optionElement.addEventListener(
        'click',
        event => {
          event.stopPropagation()

          setValueFor(
            id,
            optionElement.dataset
              .dropdownOption
          )

          state.openDropdown = null

          render()
        }
      )
    })
}

function closeDropdownMenus() {
  document
    .getElementById(
      'active-dropdown-menu'
    )
    ?.remove()
}

// ============================================================================
// INITIAL RENDER
// ============================================================================

state.videos = []
render()

